import pandas as pd

dados = {
    "nome_do_jogador": ["Everson", "Incrível Hulk", "Fábio", "Edu", "Diego Tardeli"],
    "salario_do_jogador": [150000.00, 850000.00, 100000.00, 150000.00, None],
    "posicao_jogador": ["Goleiro", "Atacante", "Goleiro", "Atacante", "Atacante"],
    "nome_time_jogador": ["Atlético", "Atlético", "Cruzeiro", "Cruzeiro", None],
    "nome_estado_jogador": ["MG", "MG", "MG", "MG", None]
}

df = pd.DataFrame(dados)

print("\n1) Jogadores com salário acima de 20.000:")
print(df[df["salario_do_jogador"] > 20000][["nome_do_jogador", "nome_time_jogador"]])

print("\n2) Jogadores dos times de MG:")
print(df[df["nome_estado_jogador"] == "MG"][["nome_do_jogador", "salario_do_jogador"]])

print("\n3) Jogadores cujo nome contenha a letra 'u':")
print(df[df["nome_do_jogador"].str.lower().str.contains("u")][["nome_do_jogador", "nome_time_jogador"]])

print("\n4) Jogadores ordenados por salário (decrescente):")
print(df.sort_values(by="salario_do_jogador", ascending=False)[["nome_do_jogador", "salario_do_jogador", "nome_time_jogador"]])

print("\n5) Ordenado por time (crescente) e salário (decrescente):")
print(df.sort_values(by=["nome_time_jogador", "salario_do_jogador"], ascending=[True, False])[["nome_do_jogador", "salario_do_jogador", "nome_time_jogador"]])

print("\n6) Quantidade de jogadores por time:")
print(df.groupby("nome_time_jogador").size())

print("\n7) Média salarial por time:")
print(df.groupby("nome_time_jogador")["salario_do_jogador"].mean())
