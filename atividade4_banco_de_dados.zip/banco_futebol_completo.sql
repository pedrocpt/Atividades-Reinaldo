-- Banco de Dados - Futebol
-- Script completo: criação das tabelas, inserts e consultas

-----------------------------------------
-- CRIAÇÃO DE TABELAS
-----------------------------------------

create table posicao(
    idPosicao int primary key,
    nome varchar(20) not null
);

create table time(
    idTime int primary key,
    nome varchar(50) not null,
    estado char(2)
);

create table jogador(
    idJogador int primary key,
    nome varchar(100) not null,
    salario numeric(10,2),
    dataNascimento datetime,
    idPosicao int not null,
    idTime int null,
    foreign key(idPosicao) references posicao(idPosicao),
    foreign key(idTime) references time(idTime)
);

-----------------------------------------
-- INSERTS
-----------------------------------------

insert into posicao(idPosicao, nome)
values (1, 'Goleiro'),
       (2, 'Zagueiro'),
       (3, 'Meio-campo'),
       (4, 'Atacante');

insert into time(idTime, nome, estado)
values (1, 'Atlético', 'MG'),
       (2, 'Cruzeiro', 'MG'),
       (3, 'Flamengo', 'RJ');

set dateformat dmy;

insert into jogador(idJogador, nome, salario, dataNascimento, idPosicao, idTime)
values (1, 'Everson', 150000, '01/10/1995', 1, 1),
       (2, 'Incrível Hulk', 850000, '12/10/1990', 4, 1),
       (3, 'Fábio', 100000, '11/04/1982', 1, 2),
       (4, 'Edu', 150000, '10/09/1983', 4, 2),
       (5, 'Diego Tardeli', null, '03/05/1991', 4, null);

-----------------------------------------
-- CONSULTAS DA ATIVIDADE
-----------------------------------------

-- 1
select * from posicao;

-- 2
select nome,
       estado as "Estado do Time"
from time;

-- 3
select nome,
       salario,
       dataNascimento
from jogador
order by dataNascimento desc;

-- 4
select nome,
       salario,
       dataNascimento
from jogador
order by salario;

-- 5
select *
from jogador
where idTime = 2;

-- 6
select nome,
       salario
from jogador
where idTime = 1;

-- 7
select distinct idPosicao
from jogador;

-- 8
select nome,
       salario
from jogador
where salario <= 200000
order by salario desc;

-- 9
select nome,
       salario
from jogador
where nome like 'I%';

-- 10
select nome,
       dataNascimento
from jogador
where nome like 'F%o';
